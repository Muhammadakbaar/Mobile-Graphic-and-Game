[2.0.0] 2018-02-07
Fixed issue with IAP_PURCHASING flag not set on project load
